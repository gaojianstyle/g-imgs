import { UploadedImageModel } from '@/common/model'

export default interface UploadedImageListStateTypes {
  uploadedImageList: UploadedImageModel[]
}
