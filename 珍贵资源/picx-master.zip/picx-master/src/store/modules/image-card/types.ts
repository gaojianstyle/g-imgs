import { UploadedImageModel } from '@/common/model'

export interface ImageCardStateTypes {
  imgCardArr: UploadedImageModel[]
}
