import { UserConfigInfoModel } from '@/common/model'

export default interface UserConfigInfoStateTypes {
  userConfigInfo: UserConfigInfoModel
}
