import { UserSettingsModel } from '@/common/model'

export default interface UserSettingsStateTypes {
  userSettings: UserSettingsModel
}
