export default interface UploadSettingsStateTypes {
  uploadSettings: {
    isSetMaxSize: boolean
    imageMaxSize: number
  }
}
