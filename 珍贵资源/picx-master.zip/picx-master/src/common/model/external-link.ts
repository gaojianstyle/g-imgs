export enum ExternalLinkType {
  staticaly = 'staticaly',
  jsdelivr = 'jsdelivr',
  github = 'github',
  zzko = 'zzko'
}
