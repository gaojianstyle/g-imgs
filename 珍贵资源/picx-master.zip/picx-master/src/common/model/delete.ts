export enum DeleteStatusEnum {
  deleted = 'deleted',
  allDeleted = 'allDeleted',
  deleteFail = 'deleteFail'
}
